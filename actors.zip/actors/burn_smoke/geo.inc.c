// 0x17000084
const GeoLayout burn_smoke_geo[] = {
   GEO_NODE_START(),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_TRANSPARENT, burn_smoke_seg4_dl_04022070),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
