#include "anim_050008D0.inc.c"
#include "anim_050009D0.inc.c"
