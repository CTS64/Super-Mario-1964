#include "anim_05009A04.inc.c"
#include "anim_05009AFC.inc.c"
