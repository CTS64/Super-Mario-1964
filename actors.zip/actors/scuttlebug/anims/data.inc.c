#include "anim_0601504C.inc.c"
