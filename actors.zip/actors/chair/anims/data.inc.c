#include "anim_0500576C.inc.c"
