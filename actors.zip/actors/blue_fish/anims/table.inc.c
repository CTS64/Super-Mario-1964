// 0x0301C2B0
const struct Animation *const blue_fish_seg3_anims_0301C2B0[] = {
    &blue_fish_seg3_anim_0301C298,
    NULL,
};
