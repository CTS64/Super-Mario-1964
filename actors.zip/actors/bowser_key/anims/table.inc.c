// 0x030172D0
const struct Animation *const bowser_key_seg3_anims_list[] = {
    &bowser_key_seg3_anim_unlock_door, // id 0
    &bowser_key_seg3_anim_course_exit, // id 1
};
