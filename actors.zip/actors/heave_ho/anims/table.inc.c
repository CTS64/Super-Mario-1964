// 0x0501534C
const struct Animation *const heave_ho_seg5_anims_0501534C[] = {
    &heave_ho_seg5_anim_05015118,
    &heave_ho_seg5_anim_05015334,
    &heave_ho_seg5_anim_05014F28,
};
