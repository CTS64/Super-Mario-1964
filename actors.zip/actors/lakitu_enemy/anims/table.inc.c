// 0x050144D4
const struct Animation *const lakitu_enemy_seg5_anims_050144D4[] = {
    &lakitu_enemy_seg5_anim_05013EDC,
    &lakitu_enemy_seg5_anim_050140E8,
    &lakitu_enemy_seg5_anim_050142E0,
    &lakitu_enemy_seg5_anim_050144BC,
    NULL,
    NULL,
    NULL,
};
