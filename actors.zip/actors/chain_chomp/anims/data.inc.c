#include "anim_06025160.inc.c"
