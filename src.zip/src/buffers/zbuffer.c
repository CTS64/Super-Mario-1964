#include <ultra64.h>

#include "config.h"
#include "zbuffer.h"

ALIGNED8 u16 gZBuffer[SCREEN_WIDTH * SCREEN_HEIGHT];
