#ifndef DEBUG_COURSE_H
#define DEBUG_COURSE_H

void nop_change_course(void);

#endif // DEBUG_COURSE_H
