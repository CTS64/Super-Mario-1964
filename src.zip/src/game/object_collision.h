#ifndef OBJECT_COLLISION_H
#define OBJECT_COLLISION_H

void detect_object_collisions(void);

#endif // OBJECT_COLLISION_H
