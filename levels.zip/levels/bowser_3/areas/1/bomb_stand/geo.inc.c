// 0x0E000380
const GeoLayout bowser_3_geo_000380[] = {
   GEO_CULLING_RADIUS(700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bowser_3_seg7_dl_07004958),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
