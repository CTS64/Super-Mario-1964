// 0x0E000758
const GeoLayout bitfs_geo_000758[] = {
   GEO_CULLING_RADIUS(600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bitfs_seg7_dl_07011798),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
