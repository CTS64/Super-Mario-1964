// 0x0E0004E0
const GeoLayout bitfs_geo_0004E0[] = {
   GEO_CULLING_RADIUS(2500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07003C60),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
