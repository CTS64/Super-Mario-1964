// 0x0E000480
const GeoLayout geo_bitdw_000480[] = {
   GEO_CULLING_RADIUS(1500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_070065F0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
