// 0x0E000450
const GeoLayout geo_bitdw_000450[] = {
   GEO_CULLING_RADIUS(1300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_07005078),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
