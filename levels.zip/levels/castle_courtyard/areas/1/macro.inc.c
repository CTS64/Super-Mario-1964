// 0x07006E20 - 0x07006E4A
const MacroObject castle_courtyard_seg7_macro_objs[] = {
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_wooden_signpost, /*yaw*/ 225, /*pos*/  3180,    20,   330, /*behParam*/ DIALOG_158),
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_wooden_signpost, /*yaw*/ 135, /*pos*/ -3180,    20,   330, /*behParam*/ DIALOG_159),
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_wooden_signpost, /*yaw*/   0, /*pos*/   300,     0, -3600, /*behParam*/ DIALOG_102),
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_wooden_signpost, /*yaw*/   0, /*pos*/  -300,     0, -3600, /*behParam*/ DIALOG_160),
    MACRO_OBJECT_END(),
};
