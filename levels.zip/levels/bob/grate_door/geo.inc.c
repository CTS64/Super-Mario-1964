// 0x0E000470
const GeoLayout bob_geo_000470[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bob_seg7_dl_0700E8A0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
