// 0x07000000 - 0x07000002
ALIGNED8 static const u8 bowser_1_seg7_texture_07000000[] = {
#include "levels/bowser_1/0.rgba16.inc.c"
};

// 0x07001000 - 0x07001002
ALIGNED8 static const u8 bowser_1_seg7_texture_07001000[] = {
#include "levels/bowser_1/1.rgba16.inc.c"
};

// 0x07001800 - 0x07001802
ALIGNED8 static const u8 bowser_1_seg7_texture_07001800[] = {
#include "levels/bowser_1/2.rgba16.inc.c"
};
