// 0x0E000520
const GeoLayout bits_geo_000520[] = {
   GEO_CULLING_RADIUS(1100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700B820),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
