// 0x0E0005F8
const GeoLayout bits_geo_0005F8[] = {
   GEO_CULLING_RADIUS(700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07012D40),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
