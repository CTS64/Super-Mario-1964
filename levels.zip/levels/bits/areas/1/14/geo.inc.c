// 0x0E000550
const GeoLayout bits_geo_000550[] = {
   GEO_CULLING_RADIUS(2900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700CDC0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
