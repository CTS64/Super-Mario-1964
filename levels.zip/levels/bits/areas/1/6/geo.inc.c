// 0x0E000490
const GeoLayout bits_geo_000490[] = {
   GEO_CULLING_RADIUS(1000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, bits_seg7_dl_07007C28),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
