// 0x0E0005B0
const GeoLayout bits_geo_0005B0[] = {
   GEO_CULLING_RADIUS(2700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700FC70),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
